public class Query {
    private String query;
    private String testo_stato_query;
    private String testoFormattato;
    private int num_stato_query;

    public Query(String query, String testo_stato_query, String testoFormattato, int num_stato_query ) {
        this.query = query;
        this.testo_stato_query = testo_stato_query;
        this.testoFormattato = testoFormattato;
        this.num_stato_query= num_stato_query;
    }

    public String getQuery() {
        return query;
    }

    public String getTesto_stato_query() {
        return testo_stato_query;
    }
    public int getNum_stato_query() {
        return num_stato_query;
    }

    public String getTestoFormattato() {
        return testoFormattato;
    }

    @Override
    public String toString() {
        return query +"-->"+ testoFormattato ;
    }
}
